<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;
use App\Entity\Haie;


class DevisController extends AbstractController
{
    #[Route('/devis', name: 'app_devis')]
    public function index(ManagerRegistry $doctrine): Response
    {
        $request = Request::createFromGlobals();
        $nomHaie = $request->get('haie');
        $longueur = $request->get('longueur');
        $hauteur = $request->get('hauteur');
        $session = new Session();
        $choix = $session->get('choix');
        $infoHaie = $doctrine->getRepository(Haie::class)->find($nomHaie);
   

        return $this->render('devis/index.html.twig', [
            'controller_name' => 'DevisController', 'choix' => $choix, 'nomHaie' => $nomHaie, 'longueur' => $longueur, 'hauteur' => $hauteur, 'infoHaie' => $infoHaie 
        ]);
    }
}
