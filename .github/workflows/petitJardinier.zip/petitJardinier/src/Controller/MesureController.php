<?php

namespace App\Controller;

use App\Entity\Haie;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\Request;

class MesureController extends AbstractController
{
    #[Route('/mesure', name: 'app_mesure')]
    public function index(ManagerRegistry $doctrine): Response
    {
        
        $request = Request::createFromGlobals();
        $choix=$request->get('choix');
        $session = new Session();
        $session->set('choix', $choix);
        $haies = $doctrine->getRepository(Haie::class)->findAll();

        return $this->render('mesure/index.html.twig', [
            'controller_name' => 'MesureController','haies'=>$haies
        ]);
    }
}
